const mongoose = require("mongoose");

mongoose
  .connect("<CONNECT_URL>", { // Replace with your MongoDB connection string
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log("Connected to DB");
  })
  .catch((error) => {
    console.log("Error connecting to DB: ", error);
  });
