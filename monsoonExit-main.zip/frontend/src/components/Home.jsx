import React, { useEffect, useState } from "react";
import { Card, CardActions, CardContent, CardMedia, Button, Typography, Grid } from "@mui/material";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const Home = () => {
  const [blogs, setBlogs] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    axios.get("http://localhost:3001/get")
      .then((response) => {
        setBlogs(response.data);
      })
      .catch((error) => {
        console.error("There was an error fetching the blog data!", error);
      });
  }, []);

  const handleDelete = (id) => {
    axios.delete(`http://localhost:3001/delete/${id}`)
      .then(() => {
        setBlogs(blogs.filter(blog => blog._id !== id));
      })
      .catch((error) => {
        console.error("There was an error deleting the blog!", error);
      });
  };

  const handleUpdate = (id) => {
    navigate(`/update/${id}`); // Navigate to the update page with the blog ID
  };

  return (
    <Grid container spacing={2} padding={2}>
      {blogs.map((blog) => (
        <Grid item xs={12} sm={6} md={4} key={blog._id}>
          <Card>
            <CardMedia
              component="img"
              height="140"
              image={blog.img_url}
              alt={blog.title}
            />
            <CardContent>
              <Typography gutterBottom variant="h5" component="div">
                {blog.title}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {blog.content}
              </Typography>
            </CardContent>
            <CardActions>
              <Button 
                size="small" 
                color="secondary" 
                variant="contained" 
                onClick={() => handleDelete(blog._id)}>
                DELETE
              </Button>
              <Button 
                size="small" 
                color="secondary" 
                variant="contained" 
                onClick={() => handleUpdate(blog._id)}>
                UPDATE
              </Button>
            </CardActions>
          </Card>
        </Grid>
      ))}
    </Grid>
  );
};

export default Home;
